--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE spotify;
--
-- Name: spotify; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE spotify WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Thai_Thailand.874';


ALTER DATABASE spotify OWNER TO postgres;

\connect spotify

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: artist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.artist (
    artistid character(5) NOT NULL,
    name text NOT NULL,
    no_followers integer
);


ALTER TABLE public.artist OWNER TO postgres;

--
-- Name: cost; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cost (
    year character(4) NOT NULL,
    cogs numeric(25,2) NOT NULL,
    researchdev_cost numeric(25,2) NOT NULL,
    operating_cost numeric(25,2) NOT NULL
);


ALTER TABLE public.cost OWNER TO postgres;

--
-- Name: credit_card; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credit_card (
    cardid character varying(5),
    cardname text NOT NULL
);


ALTER TABLE public.credit_card OWNER TO postgres;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    employeeid character varying(20) NOT NULL,
    fname text NOT NULL,
    lname text NOT NULL,
    email character varying(50),
    "position" text NOT NULL,
    salary integer,
    starting_date date
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: market_share; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.market_share (
    year character(4) NOT NULL,
    platform text NOT NULL,
    percent numeric(10,2) NOT NULL
);


ALTER TABLE public.market_share OWNER TO postgres;

--
-- Name: playlist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playlist (
    playlistid character varying(7) NOT NULL,
    playlistname text NOT NULL,
    userid character(5),
    no_followers integer NOT NULL
);


ALTER TABLE public.playlist OWNER TO postgres;

--
-- Name: podcast; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.podcast (
    podcastid character varying(30) NOT NULL,
    podcastname text NOT NULL,
    genre text NOT NULL,
    release_date date,
    stream integer,
    podcasterid character varying(30) NOT NULL
);


ALTER TABLE public.podcast OWNER TO postgres;

--
-- Name: podcaster; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.podcaster (
    podcasterid character varying(15) NOT NULL,
    fname text NOT NULL,
    lname text NOT NULL
);


ALTER TABLE public.podcaster OWNER TO postgres;

--
-- Name: region; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.region (
    regionid character(2) NOT NULL,
    region text
);


ALTER TABLE public.region OWNER TO postgres;

--
-- Name: revenue_ad_supported; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.revenue_ad_supported (
    year character(4) NOT NULL,
    revenue numeric(25,2) NOT NULL,
    yearly_active_users integer NOT NULL
);


ALTER TABLE public.revenue_ad_supported OWNER TO postgres;

--
-- Name: revenue_premium; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.revenue_premium (
    year character(4) NOT NULL,
    revenue numeric(25,2) NOT NULL,
    yearly_active_users integer NOT NULL
);


ALTER TABLE public.revenue_premium OWNER TO postgres;

--
-- Name: song; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.song (
    songid character varying(30) NOT NULL,
    name text NOT NULL,
    genre text NOT NULL,
    stream integer,
    release_date date,
    no_time_charted integer
);


ALTER TABLE public.song OWNER TO postgres;

--
-- Name: song_artist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.song_artist (
    song_songid character varying(30),
    artist_artistid character(5)
);


ALTER TABLE public.song_artist OWNER TO postgres;

--
-- Name: type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.type (
    id character varying(50) NOT NULL,
    type text NOT NULL,
    name character varying(200) NOT NULL
);


ALTER TABLE public.type OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    userid character(5) NOT NULL,
    fname text,
    lname text,
    email character varying(50) NOT NULL,
    gender text,
    regionid character(2),
    birthday date,
    is_user_premium boolean NOT NULL,
    credit_card_id character varying(5),
    first_date date
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Data for Name: artist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.artist (artistid, name, no_followers) FROM stdin;
\.
COPY public.artist (artistid, name, no_followers) FROM '$$PATH$$/3075.dat';

--
-- Data for Name: cost; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cost (year, cogs, researchdev_cost, operating_cost) FROM stdin;
\.
COPY public.cost (year, cogs, researchdev_cost, operating_cost) FROM '$$PATH$$/3088.dat';

--
-- Data for Name: credit_card; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credit_card (cardid, cardname) FROM stdin;
\.
COPY public.credit_card (cardid, cardname) FROM '$$PATH$$/3078.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (employeeid, fname, lname, email, "position", salary, starting_date) FROM stdin;
\.
COPY public.employee (employeeid, fname, lname, email, "position", salary, starting_date) FROM '$$PATH$$/3082.dat';

--
-- Data for Name: market_share; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.market_share (year, platform, percent) FROM stdin;
\.
COPY public.market_share (year, platform, percent) FROM '$$PATH$$/3081.dat';

--
-- Data for Name: playlist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.playlist (playlistid, playlistname, userid, no_followers) FROM stdin;
\.
COPY public.playlist (playlistid, playlistname, userid, no_followers) FROM '$$PATH$$/3080.dat';

--
-- Data for Name: podcast; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.podcast (podcastid, podcastname, genre, release_date, stream, podcasterid) FROM stdin;
\.
COPY public.podcast (podcastid, podcastname, genre, release_date, stream, podcasterid) FROM '$$PATH$$/3087.dat';

--
-- Data for Name: podcaster; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.podcaster (podcasterid, fname, lname) FROM stdin;
\.
COPY public.podcaster (podcasterid, fname, lname) FROM '$$PATH$$/3074.dat';

--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.region (regionid, region) FROM stdin;
\.
COPY public.region (regionid, region) FROM '$$PATH$$/3079.dat';

--
-- Data for Name: revenue_ad_supported; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.revenue_ad_supported (year, revenue, yearly_active_users) FROM stdin;
\.
COPY public.revenue_ad_supported (year, revenue, yearly_active_users) FROM '$$PATH$$/3085.dat';

--
-- Data for Name: revenue_premium; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.revenue_premium (year, revenue, yearly_active_users) FROM stdin;
\.
COPY public.revenue_premium (year, revenue, yearly_active_users) FROM '$$PATH$$/3084.dat';

--
-- Data for Name: song; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.song (songid, name, genre, stream, release_date, no_time_charted) FROM stdin;
\.
COPY public.song (songid, name, genre, stream, release_date, no_time_charted) FROM '$$PATH$$/3076.dat';

--
-- Data for Name: song_artist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.song_artist (song_songid, artist_artistid) FROM stdin;
\.
COPY public.song_artist (song_songid, artist_artistid) FROM '$$PATH$$/3086.dat';

--
-- Data for Name: type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.type (id, type, name) FROM stdin;
\.
COPY public.type (id, type, name) FROM '$$PATH$$/3077.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (userid, fname, lname, email, gender, regionid, birthday, is_user_premium, credit_card_id, first_date) FROM stdin;
\.
COPY public."user" (userid, fname, lname, email, gender, regionid, birthday, is_user_premium, credit_card_id, first_date) FROM '$$PATH$$/3083.dat';

--
-- Name: artist artist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT artist_pkey PRIMARY KEY (artistid);


--
-- Name: cost cost_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cost
    ADD CONSTRAINT cost_pkey PRIMARY KEY (year);


--
-- Name: credit_card credit_card_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_card
    ADD CONSTRAINT credit_card_pkey PRIMARY KEY (cardname);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (employeeid);


--
-- Name: playlist playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT playlist_pkey PRIMARY KEY (playlistid);


--
-- Name: podcast podcast_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcast
    ADD CONSTRAINT podcast_pkey PRIMARY KEY (podcastid);


--
-- Name: podcaster podcaster_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcaster
    ADD CONSTRAINT podcaster_pkey PRIMARY KEY (podcasterid);


--
-- Name: region region_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.region
    ADD CONSTRAINT region_pkey PRIMARY KEY (regionid);


--
-- Name: revenue_ad_supported revenue_ad_supported_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.revenue_ad_supported
    ADD CONSTRAINT revenue_ad_supported_pkey PRIMARY KEY (year);


--
-- Name: revenue_premium revenue_premium_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.revenue_premium
    ADD CONSTRAINT revenue_premium_pkey PRIMARY KEY (year);


--
-- Name: song song_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song
    ADD CONSTRAINT song_pkey PRIMARY KEY (songid);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (userid);


--
-- Name: playlist playlist_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT playlist_userid_fkey FOREIGN KEY (userid) REFERENCES public."user"(userid) NOT VALID;


--
-- Name: song_artist song_artist_artist_artistid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_artist
    ADD CONSTRAINT song_artist_artist_artistid_fkey FOREIGN KEY (artist_artistid) REFERENCES public.artist(artistid) NOT VALID;


--
-- Name: song_artist song_artist_song_songid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_artist
    ADD CONSTRAINT song_artist_song_songid_fkey FOREIGN KEY (song_songid) REFERENCES public.song(songid) NOT VALID;


--
-- Name: user user_credit_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_credit_card_id_fkey FOREIGN KEY (credit_card_id) REFERENCES public.credit_card(cardname) NOT VALID;


--
-- Name: user user_regionid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_regionid_fkey FOREIGN KEY (regionid) REFERENCES public.region(regionid) NOT VALID;


--
-- PostgreSQL database dump complete
--

